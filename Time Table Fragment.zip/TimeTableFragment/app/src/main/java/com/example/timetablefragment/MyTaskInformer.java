package com.example.timetablefragment;

public interface MyTaskInformer {
    void onTaskDone(Events[] output);
}
